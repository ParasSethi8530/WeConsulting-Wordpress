<?php
/**
 * The base configuration for WordPress
 *
 * The wp-config.php creation script uses this file during the installation.
 * You don't have to use the website, you can copy this file to "wp-config.php"
 * and fill in the values.
 *
 * This file contains the following configurations:
 *
 * * Database settings
 * * Secret keys
 * * Database table prefix
 * * ABSPATH
 *
 * @link https://developer.wordpress.org/advanced-administration/wordpress/wp-config/
 *
 * @package WordPress
 */

// ** Database settings - You can get this info from your web host ** //
/** The name of the database for WordPress */
define( 'DB_NAME', 'WeConsulting' );

/** Database username */
define( 'DB_USER', 'root' );

/** Database password */
define( 'DB_PASSWORD', '' );

/** Database hostname */
define( 'DB_HOST', 'localhost' );

/** Database charset to use in creating database tables. */
define( 'DB_CHARSET', 'utf8mb4' );

/** The database collate type. Don't change this if in doubt. */
define( 'DB_COLLATE', '' );

/**#@+
 * Authentication unique keys and salts.
 *
 * Change these to different unique phrases! You can generate these using
 * the {@link https://api.wordpress.org/secret-key/1.1/salt/ WordPress.org secret-key service}.
 *
 * You can change these at any point in time to invalidate all existing cookies.
 * This will force all users to have to log in again.
 *
 * @since 2.6.0
 */
define( 'AUTH_KEY',         'PGWnMmia#mI:~#Kq^0BD%$)N[{sO%_vqJ9 Y3#ZXHF+RZbd;bRjpWzk_WO(SDJ9^' );
define( 'SECURE_AUTH_KEY',  'D5,lYQ_J9X#$gv}efK[s+};ni}L*m Le*/>/bXW6+h#w2h#0tiN.UsL6eAL=qaoV' );
define( 'LOGGED_IN_KEY',    '|!6-mPV!^T`G,qEWa9(iMw|~uSb&H)]}A)zdat[QF-!Y<_QcW8-U`=*)hH9kh+~L' );
define( 'NONCE_KEY',        'spoGHRF)7%RsMoD%!)Hhj[L^<N3FO2rm_nz$}dR#~PWTwf:XPrXA=,wI$Q.OACC9' );
define( 'AUTH_SALT',        'IcZk>_1^BAK#F7^c;PHvKpXE7qu8E-grligi@&}MS*e2r6C|<]HQ%I&~bT[9HSy6' );
define( 'SECURE_AUTH_SALT', '(yYmuO<9~2(&dumFLM3bF]_t0{SFob%F![U$}-4.%?QKL;o[ J/s[,rpLJ* `Ar%' );
define( 'LOGGED_IN_SALT',   'TRfN,u `Ciu>#|WYFl2X*Be;(#|HR>v=VtgJ5jq,4x?Y9w%mF![X`VISetQ:44b>' );
define( 'NONCE_SALT',       'IGVe:R(=/fvA:`^~as6[<a:9nI^&Uj>5Q(_=xPehArTP1DCLJD-@8E]}[08DcWQX' );

/**#@-*/

/**
 * WordPress database table prefix.
 *
 * You can have multiple installations in one database if you give each
 * a unique prefix. Only numbers, letters, and underscores please!
 */
$table_prefix = 'wp_';

/**
 * For developers: WordPress debugging mode.
 *
 * Change this to true to enable the display of notices during development.
 * It is strongly recommended that plugin and theme developers use WP_DEBUG
 * in their development environments.
 *
 * For information on other constants that can be used for debugging,
 * visit the documentation.
 *
 * @link https://developer.wordpress.org/advanced-administration/debug/debug-wordpress/
 */
define( 'WP_DEBUG', false );

/* Add any custom values between this line and the "stop editing" line. */



/* That's all, stop editing! Happy publishing. */

/** Absolute path to the WordPress directory. */
if ( ! defined( 'ABSPATH' ) ) {
	define( 'ABSPATH', __DIR__ . '/' );
}

/** Sets up WordPress vars and included files. */
require_once ABSPATH . 'wp-settings.php';
